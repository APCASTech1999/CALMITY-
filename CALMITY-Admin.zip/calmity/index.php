<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
  <?php include "style.css" ?>
</style>
     <section class="main">
      <div class="main-top">
        <h1>Admin Dashboard</h1>
        <i class="fas fa-user-cog"></i>
      </div>
      <?php 
                if(isset($_SESSION['status'])) {
                echo "<h5 class='alert alert-success'>".$_SESSION['status']."</h5>";
                unset($_SESSION['status']);
                }
            ?>   
      <section class="attendance">
        <div class="attendance-list">
          <h1>Reports</h1>
          <table class="table">
            <thead>
              <tr>
                <th>Id</th>
                <th>Barangay</th>
                <th>City</th>
                <th>Disaster</th>
                <th>Name</th>
                <th>Status</th>
                <th>Image</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <?php
                  include('dbcon.php');
                  
                  $ref_table = 'reports';
                  $fetchdata = $database->getReference($ref_table)->getValue();

                  if($fetchdata > 0)
                  {
                    $i=1;
                    foreach($fetchdata as $key => $row)
                    {
                      ?>
                      <tr>
                        <td><?=$i++;?></td>
                        <td><?=$row['barangay'];?></td>
                        <td><?=$row['city'];?></td>
                        <td><?=$row['disaster'];?></td>
                        <td><?=$row['fname'];?></td>
                        <td><?=$row['status'];?></td>
                        <td><img src="<?= $row['imageUrl']; ?>" alt="Image" style="width: 64px; height: auto;"></td> <!-- Display image -->
                        <td><button>View</button></td>
                        </tr>
                     <!-- <td>
                        <a href="edit-contact.php" class="btn btn-primary btn-sm">Edit</a>
                      </td>

                      <td>
                        <a href="delete-contact.php" class="btn btn-danger btn-sm">Delete</a>
                      </td>
                    -->
                    
                      
                      <?php
                    }

                  }
                  else
                  {
                    ?>
                      <tr>
                        <td colspan="7">No record Found</td>
                      </tr>
                    <?php
                  }

              ?>
            </tbody>
          </table>
        </div>
      </section>
    </section>

<?php
include('includes/footer.php');
?>