
<?php
session_start();
include('includes/header.php');
include('includes/navbar2.php')
?>

<style>
  <?php include "style.css" ?>
</style>

<div id="cardprivacy">
    <div id="cardlogin-content">
        <div id="cardlogin-title">
            <h2>CALMITY - Privacy Policy</h2>
            <div class="underlineprivacy-title"></div>
        </div>
        <form method="post" class="form" action="code.php"> <!-- Ensure correct form action -->
        <div class="h2"><h2></h2></div><br>
        <center>
            <b>This Privacy Policy governs the manner in which APCAS Tech collects, uses, maintains, and discloses information collected from users of the CALMITY mobile application.</b>
            <br><br>
            <b>Personal Identification Information</b>
            <br><br>
            We may collect personal identification information from Users in various ways, including, but not limited to, when Users install the App, register on the App, subscribe to the newsletter, respond to a survey, fill out a form, and in connection with other activities, services, features, or resources we make available on the App. Users may be asked for, as appropriate, name, email address, phone number, and other relevant information. We will collect personal identification information from Users only if they voluntarily submit such information to us. Users can always refuse to supply personal identification information, except that it may prevent them from engaging in certain App-related activities.
            <br><br>
            <b>Non-Personal Identification Information</b>
            <br><br>
            We may collect non-personal identification information about Users whenever they interact with the App. Non-personal identification information may include the type of device, the device's operating system, unique device identifiers, IP address, mobile network information, and other technical information about Users' means of connection to the App, such as the Internet service provider utilized and other similar information.
            <br><Br>
            <b>How We Use Collected Information</b>
            <br><br>
            APCAS Tech may collect and use Users' personal information for the following purposes:
<           br><Br>
            To improve customer service: Information you provide helps us respond to your customer service requests and support needs more efficiently.
            To personalize user experience: We may use information in the aggregate to understand how our Users as a group use the services and resources provided on the App.
            To improve the App: We may use feedback you provide to improve our products and services.
            To send periodic emails: We may use the email address to send User information and updates pertaining to their order or subscription. It may also be used to respond to their inquiries, questions, and/or other requests.
            <br><br>
            <b>How We Protect Your Information</b>
            <br><br>
            We adopt appropriate data collection, storage, and processing practices and security measures to protect against unauthorized access, alteration, disclosure, or destruction of your personal information, username, password, transaction information, and data stored on the App.
        </center>
       </form>
    </div>
</div>

<?php
include('includes/footer.php');
?>