<?php
session_start();
include('dbcon.php');

if(isset($_POST['login_btn']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];

    try {
        $user = $auth->getUserByEmail($email);

        // Verify password
        $signInResult = $auth->signInWithEmailAndPassword($email, $password);
        $idTokenString = $signInResult->idToken();

        // Verify ID token
        $verifiedIdToken = $auth->verifyIdToken($idTokenString);
        $uid = $verifiedIdToken->claims()->get('sub');

        // Set session variables
        $_SESSION['verified_user_id'] = $uid;
        $_SESSION['idTokenString'] = $idTokenString;
        $_SESSION['status'] = "Logged in successfully";
        
        header('Location: index.php');
        exit();
    } catch (\Kreait\Firebase\Exception\Auth\UserNotFound $e) {
        $_SESSION['status'] = "Invalid Email Address";
        header('Location: login.php');
        exit();
    } catch (\Kreait\Firebase\Exception\Auth\InvalidPassword $e) {
        $_SESSION['status'] = "Wrong Password";
        header('Location: login.php');
        exit();
    } catch (\Exception $e) {
        $_SESSION['status'] = "An error occurred: " . $e->getMessage();
        header('Location: login.php');
        exit();
    }
}
else
{
    $_SESSION['status'] = "Not allowed";
    header('Location: login.php');
    exit();
}
?>
