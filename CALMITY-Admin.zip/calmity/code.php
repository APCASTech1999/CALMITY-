<?php
session_start();
include('dbcon.php');

// Register Code
if(isset($_POST['register_btn']))
{
    $fullname = $_POST['full_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if password meets minimum length requirement
    if(strlen($password) < 6) {
        $_SESSION['status'] = "Password must be at least 6 characters long.";
        header('Location: register.php');
        exit();
    }

    $userProperties = [
        'email' => $email,
        'emailVerified' => false,
        'phoneNumber' => '+91'.$phone,
        'password' => $password,
        'displayName' => $fullname,
    ];
    
    $createdUser = $auth->createUser($userProperties);

    if($createdUser)
    {
        $_SESSION['status'] = "User Created Successfully";
        header('Location: register.php');
        exit();
    }
    else
    {
        $_SESSION['status'] = "User not Created Successfully";
        header('Location: register.php');
        exit();
    }
}

?>
