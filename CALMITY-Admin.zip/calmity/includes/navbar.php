<div class="container">
    <nav>
      <ul>
        <li><a href="#" class="logo">
          <img src="./img/logo.png">
          <span class="nav-item">Calmity</span>
        </a></li>
        <li><a href="index.php">
          <i class="fas fa-chart-bar"></i>
          <span class="nav-item">Dashboard</span>
        </a></li>
        <li><a href="evacuation.php">
          <i class="fas fa-building"></i>
          <span class="nav-item">Evacuation</span>
        </a></li>
        <li><a href="add-evac.php">
          <i class="fas fa-plus"></i>
          <span class="nav-item">Add Evacuation</span>
        </a></li>
        <li><a href="user-list.php">
          <i class="fas fa-users"></i>
          <span class="nav-item">Users</span>
        </a></li>
        <li><a href="register.php">
          <i class="fas fa-user-plus"></i>
          <span class="nav-item">Register</span>
        </a></li>
        <li><a href="logout.php" class="logout">
          <i class="fas fa-sign-out-alt"></i>
          <span class="nav-item">Log out</span>
        </a></li>
      </ul>
    </nav>