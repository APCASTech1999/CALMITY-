<div class="ul2">
  <ul2>
    <li class="li2"><a class="active" href="terms-and-conditions.php">Terms and Conditions</a></li>
    <li class="li2"><a href="privacy-policy.php">Privacy Policy</a></li>
  </ul2>
</div>
