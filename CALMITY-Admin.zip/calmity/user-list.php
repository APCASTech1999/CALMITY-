<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');

?>
<style>
  <?php include "style.css" ?>
</style>
     <section class="main">
      <div class="main-top">
        <h1>Admin Dashboard</h1>
        <i class="fas fa-user-cog"></i>
      </div>
      <?php 
                if(isset($_SESSION['status'])) {
                echo "<h5 class='alert alert-success'>".$_SESSION['status']."</h5>";
                unset($_SESSION['status']);
                }
            ?>   
      <section class="attendance">
        <div class="attendance-list">
          <h1>Reports</h1>
          <table class="table">
            <thead>
              <tr>
                <th>Id</th>
                <th>Display</th>
                <th>Phone</th>
                <th>Email</th>
             <th></th>
              </tr>
            </thead>
            <tbody>
                  <?php
                  include('dbcon.php');
                  $users = $auth->listUsers();

                  $i=1;
                  foreach ($users as $user) 
                  {
                      ?>
                      <tr>
                        <td><?=$i++;?></td>
                        <td><?=$user->displayName ?></td>
                        <td><?=$user->phoneNumber ?></td>
                        <td><?=$user->email ?></td>
                      </tr>
                      <?php
                  }
                  ?>
            </tbody>
          </table>
        </div>
      </section>
    </section>

<?php
include('includes/footer.php');
?>