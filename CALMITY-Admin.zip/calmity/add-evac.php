<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
?>

<style>
  <?php include "style.css" ?>
</style>
<div id="cardevacuation">
    <div id="cardlogin-content">
        <div id="cardlogin-title">
            <h2>ADD EVACUATION</h2>
            <div class="underline-evacuation-title"></div>
        </div>
        <form method="post" class="form" action="add-evac-code.php" enctype="multipart/form-data"> <!-- Ensure correct form action -->
            <label for="placename" style="padding-top:13px">Place Name</label>
            <input id="placename" class="form-content" type="text" name="placename" autocomplete="on" required />
            <div class="form-border"></div>

            <label for="address" style="padding-top:22px">Address</label>
            <input id="address" class="form-content" type="text" name="address" required />
            <div class="form-border"></div>

            <label for="barangay" style="padding-top:22px">Barangay</label>
            <input id="barangay" class="form-content" type="text" name="barangay" required />
            <div class="form-border"></div>

            <label for="city" style="padding-top:22px">City</label>
            <input id="city" class="form-content" type="text" name="city" required />
            <div class="form-border"></div>

            <label for="capacity" style="padding-top:22px">Capacity</label>
            <input id="capacity" class="form-content" type="number" name="capacity" required />
            <div class="form-border"></div>          

            <label for="coordinates" style="padding-top:22px">Location Coordinates (latitude,longitude)</label>
            <input id="coordinates" class="form-content" type="text" name="coordinates" required />
            <div class="form-border"></div>

            <label for="picture" style="padding-top:22px">Upload Picture</label>
            <input id="picture" class="form-content" type="file" name="picture" required />
            <div class="form-border"></div>          

            <button id="submit-btn" type="submit" name="add_evac">ADD</button> <!-- Submit button -->
        </form>
    </div>
</div>

<?php
include('includes/footer.php');
?>
