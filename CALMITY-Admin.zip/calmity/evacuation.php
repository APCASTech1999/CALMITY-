<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
?>
<style>
  <?php include "style.css" ?>
</style>
<section class="main">
  <div class="main-top">
    <h1>Evacuation</h1>
    <i class="fas fa-user-cog"></i>
  </div>
  <section class="attendance">
    <div class="attendance-list">
      <h1>Evacuation Centers</h1>
      <div id="map" style="height: 400px;"></div> <!-- Map container -->
      <table class="table">
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Barangay</th>
            <th>City</th>
            <th>Capacity</th>
            <th>Occupants</th>
            <th>Image</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php
          include('dbcon.php');

          $ref_table = 'evac_centers';
          $fetchdata = $database->getReference($ref_table)->getValue();

          if ($fetchdata) {
            $i = 1;
            foreach ($fetchdata as $key => $row) {
          ?>
              <tr>
                <td><?= $i++; ?></td>
                <td><?= $row['name']; ?></td>
                <td><?= $row['brgy']; ?></td>
                <td><?= $row['city']; ?></td>
                <td><?= $row['capacity']; ?></td>
                <td><?= $row['occupants']; ?></td>
                <td><img src="<?= $row['imgUrl']; ?>" alt="Image" style="width: 64px; height: auto;"></td> <!-- Display image -->
                <td><button onclick="showLocation(<?= $row['latitude']; ?>, <?= $row['longitude']; ?>)">View</button></td> <!-- Button to view location -->
              </tr>
          <?php
            }
          } else {
          ?>
            <tr>
              <td colspan="10">No record Found</td>
            </tr>
          <?php
          }
          ?>
        </tbody>
      </table>
    </div>
  </section>
</section>

<script>
  // Initialize Google Map
  function initMap() {
    var mapOptions = {
      center: { lat: -34.397, lng: 150.644 },
      zoom: 8
    };
    var map = new google.maps.Map(document.getElementById('map'), mapOptions);
  }

  // Show location on the map
  function showLocation(latitude, longitude) {
    var map = new google.maps.Map(document.getElementById('map'), {
      center: { lat: latitude, lng: longitude },
      zoom: 15
    });
    var marker = new google.maps.Marker({
      position: { lat: latitude, lng: longitude },
      map: map,
      title: 'Evacuation Center'
    });
  }
</script>

<!-- Load Google Maps API -->
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD6Nkl8t1n8mIem6Jlb5uMcRiksSAhF16k&callback=initMap" async defer></script>

<?php
include('includes/footer.php');
?>
