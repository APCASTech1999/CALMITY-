
<?php
session_start();
include('includes/header.php');
include('includes/navbar2.php')
?>

<style>
  <?php include "style.css" ?>
</style>

<div id="cardterms">
    <div id="cardlogin-content">
        <div id="cardlogin-title">
            <h2>CALMITY - Terms and Conditions</h2>
            <div class="underlineterms-title"></div>
        </div>
        <form method="post" class="form" action="code.php"> <!-- Ensure correct form action -->
        <div class="h2"><h2></h2></div><br>
        <center>
            <b>These terms and conditions outline the rules and regulations for the use of the CALMITY mobile application provided by APCAS Tech.

            By downloading, installing, or using the CALMITY app, you agree to be bound by these terms and conditions. If you do not agree with any part of these terms and conditions, you must not use the App.</b>   <br><br>

            1. Acceptance of Terms

            By using the CALMITY app, you agree to comply with and be bound by these terms and conditions, our Privacy Policy, and any additional terms and conditions or policies referenced herein or made available within the App. If you do not agree to all of the terms and conditions contained herein, you may not use the App.
            <br><br>
            2. Real-time Weather Monitoring

            The CALMITY app provides real-time weather monitoring services, including disaster reports and alerts. Users understand and agree that this functionality requires access to the user's exact location to provide accurate information. By using the App's weather monitoring features, you consent to the collection and use of your location data.
            <br><br>
            3. Evacuation Center Location

            The CALMITY app may display the locations of evacuation centers during disasters or emergencies. While we strive to provide accurate and up-to-date information, we cannot guarantee the availability or accuracy of evacuation center locations. Users are advised to verify the information provided by the App and follow official guidance during emergencies.
            <br><br>
            4. User Responsibilities

            Users are solely responsible for the accuracy and security of the information provided to the CALMITY app, including their location data. Users must not use the App for any unlawful or unauthorized purpose, and must comply with all applicable laws and regulations while using the App.
            <br><br>
            5. Intellectual Property

            The CALMITY app and all content and materials contained therein, including but not limited to text, graphics, logos, images, and software, are the property of APCAS Tech or its licensors and are protected by copyright and other intellectual property laws. Users may not modify, reproduce, distribute, or create derivative works based on the App or its content without the express written consent of APCAS Tech.
            <br><br>
            6. Limitation of Liability

            APCAS Tech shall not be liable for any direct, indirect, incidental, special, consequential, or exemplary damages, including but not limited to damages for loss of profits, goodwill, use, data, or other intangible losses resulting from the use or inability to use the CALMITY app.
            <br><br>
            7. Modification of Terms

            APCAS Tech reserves the right to modify or replace these terms and conditions at any time. Users will be notified of any changes to these terms and conditions within the App. Continued use of the App after any such changes shall constitute your consent to such changes.
            <br><br>
            8. Governing Law

            These terms and conditions shall be governed by and construed in accordance with the laws of Philippines, without regard to its conflict of law provisions.

            Contact Us

            If you have any questions or concerns about these terms and conditions, please contact us at <b>apcastech1999@gmail.com.</b> By using the CALMITY app, you acknowledge that you have read, understood, and agree to be bound by these terms and conditions.
        </center>  
</form>
    </div>
</div>

<?php
include('includes/footer.php');
?>