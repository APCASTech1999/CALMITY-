<?php
session_start();
include('includes/header.php');
?>
<style>
  <?php include "style.css" ?>
</style>
<div id="cardlogin">
    <div id="cardlogin-content">
      <div id="cardlogin-title">
        <h2>LOGIN</h2>
        <div class="underline-title"></div>
      </div>
      <form method="post" class="form" action="logincode.php"> <!-- Updated form action -->
            <label for="email" style="padding-top:22px">Email</label>
            <input id="email" class="form-content" type="email" name="email" required />
            <div class="form-border"></div>

            <label for="password" style="padding-top:22px">Password</label>
            <input id="password" class="form-content" type="password" name="password" required /> <!-- Changed type to password -->
            <div class="form-border"></div>
            <button id="submit-btn" type="submit" name="login_btn">LOGIN</button> <!-- Submit button -->
            <br>
            <div style="text-align: center;">
            <?php 
                if(isset($_SESSION['status'])) {
                echo "<h5 class='alert alert-success'>".$_SESSION['status']."</h5>";
                unset($_SESSION['status']);
                }
            ?>
            </div>
      </form>
    </div>
  </div>

<?php
include('includes/footer.php');
?>
