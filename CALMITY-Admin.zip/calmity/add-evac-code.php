<?php
session_start();
include('dbcon.php');

if (isset($_POST['add_evac'])) {
    // Get form data
    $placename = $_POST['placename'];
    $address = $_POST['address'];
    $coordinates = explode(',', $_POST['coordinates']); // Extract latitude and longitude from coordinates input
    $latitude = floatval($coordinates[0]); // Latitude
    $longitude = floatval($coordinates[1]); // Longitude
    $barangay = $_POST['barangay'];
    $city = $_POST['city'];
    $capacity = intval($_POST['capacity']); // Convert capacity to integer
    
    // File upload handling
    $picture = $_FILES['picture']['name'];
    $picture_tmp = $_FILES['picture']['tmp_name'];
    $target_directory = "uploads/"; // Directory where pictures will be stored
    $target_file = $target_directory . basename($picture);
    
    // Upload image to server
    if (move_uploaded_file($picture_tmp, $target_file)) {
        // Get the uploaded image URL
        $imgUrl = 'http://' . $_SERVER['HTTP_HOST'] . '/' . $target_file;
        
        // Insert data into Firebase Realtime Database
        $newPost = $database
            ->getReference('evac_centers') // Adjust the database reference as per your setup
            ->push([
                'name' => $placename,
                'address' => $address . ', ' . $barangay . ', ' . $city,
                'brgy' => $barangay,
                'city' => $city,
                'capacity' => $capacity, // Insert capacity as integer
                'imgUrl' => $imgUrl, // Insert image URL
                'latitude' => $latitude, // Insert latitude
                'longitude' => $longitude, // Insert longitude
                'occupants' => 0 // Initial occupants count
            ]);

        $_SESSION['success'] = "Evacuation center added successfully";
    } else {
        $_SESSION['status'] = "Error uploading picture";
    }

    header('Location: add-evac.php'); // Redirect to index page or wherever appropriate
    exit();
}
?>
