<?php
include('authentication.php');
include('includes/header.php');
include('includes/navbar.php');
?>

<style>
  <?php include "style.css" ?>
</style>
<div id="cardregister">
    <div id="cardlogin-content">
        <div id="cardlogin-title">
            <h2>REGISTER</h2>
            <div class="underlineregister-title"></div>
        </div>
        <form method="post" class="form" action="code.php"> <!-- Ensure correct form action -->
            <label for="full-name" style="padding-top:13px">Full Name</label>
            <input id="full-name" class="form-content" type="text" name="full_name" autocomplete="on" required />
            <div class="form-border"></div>

            <label for="phone" style="padding-top:22px">Phone No.</label>
            <input id="phone" class="form-content" type="tel" name="phone" required /> <!-- Changed type to tel for phone number -->
            <div class="form-border"></div>

            <label for="email" style="padding-top:22px">Email</label>
            <input id="email" class="form-content" type="email" name="email" required />
            <div class="form-border"></div>

            <label for="password" style="padding-top:22px">Password</label>
            <input id="password" class="form-content" type="password" name="password" required /> <!-- Changed type to password -->
            <div class="form-border"></div>
            <?php 
                if(isset($_SESSION['status'])) {
                echo "<h5 class='alert alert-success'>".$_SESSION['status']."</h5>";
                unset($_SESSION['status']);
                }
            ?>           
            <button id="submit-btn" type="submit" name="register_btn">REGISTER</button> <!-- Submit button -->
        </form>
    </div>
</div>

<?php
include('includes/footer.php');
?>
